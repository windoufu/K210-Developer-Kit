#ifndef _GUI_LVGL_H_
#define _GUI_LVGL_H_

#include "lvgl/lvgl.h"

void lvgl_disp_input_init(void);

#endif /* _GUI_LVGL_H_ */
